package br.edu.univille.poo.musicapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoomboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoomboxApplication.class, args);
	}

}
